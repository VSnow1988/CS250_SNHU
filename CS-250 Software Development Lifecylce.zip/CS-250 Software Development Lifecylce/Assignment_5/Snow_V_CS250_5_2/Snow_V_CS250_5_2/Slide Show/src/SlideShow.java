/*
 * @author vincent Snow vincent.snow@snhu.edu
 */

import java.awt.BorderLayout;
import java.awt.CardLayout;
import java.awt.EventQueue;
import java.awt.FlowLayout;
import java.awt.HeadlessException;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.text.AttributeSet.ColorAttribute;

import java.awt.Color;

public class SlideShow extends JFrame {

	//Declare Variables
	private JPanel slidePane;
	private JPanel textPane;
	private JPanel buttonPane;
	private CardLayout card;
	private CardLayout cardText;
	private JButton btnPrev;
	private JButton btnNext;
	private JLabel lblSlide;
	private JLabel lblTextArea;

	/**
	 * Create the application.
	 */
	public SlideShow() throws HeadlessException {
		initComponent();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initComponent() {
		//Initialize variables to empty objects
		card = new CardLayout();
		cardText = new CardLayout();
		slidePane = new JPanel();
		textPane = new JPanel();
		textPane.setBackground(Color.BLACK); //Apr-1-2022 Changed to make text more visible and bring out the image colors.
		textPane.setBounds(5, 470, 790, 50);
		textPane.setVisible(true);
		buttonPane = new JPanel();
		btnPrev = new JButton();
		btnNext = new JButton();
		lblSlide = new JLabel();
		lblTextArea = new JLabel();

		//Setup frame attributes
		setSize(800, 600);
		setLocationRelativeTo(null);
		setTitle("Top 5 Destinations SlideShow");
		getContentPane().setLayout(new BorderLayout(10, 50));
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		//Setting the layouts for the panels
		slidePane.setLayout(card);
		textPane.setLayout(cardText);
		
		//logic to add each of the slides and text
		for (int i = 1; i <= 5; i++) {
			lblSlide = new JLabel();
			lblTextArea = new JLabel();
			lblSlide.setText(getResizeIcon(i));
			lblTextArea.setText(getTextDescription(i));
			slidePane.add(lblSlide, "card" + i);
			textPane.add(lblTextArea, "cardText" + i);
		}

		getContentPane().add(slidePane, BorderLayout.CENTER);
		getContentPane().add(textPane, BorderLayout.SOUTH);

		buttonPane.setLayout(new FlowLayout(FlowLayout.CENTER, 20, 10));

		btnPrev.setText("Previous");
		btnPrev.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				goPrevious();
			}
		});
		buttonPane.add(btnPrev);

		btnNext.setText("Next");
		btnNext.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				goNext();
			}
		});
		buttonPane.add(btnNext);

		getContentPane().add(buttonPane, BorderLayout.SOUTH);
	}

	/**
	 * Previous Button Functionality
	 */
	private void goPrevious() {
		card.previous(slidePane);
		cardText.previous(textPane);
	}
	
	/**
	 * Next Button Functionality
	 */
	private void goNext() {
		card.next(slidePane);
		cardText.next(textPane);
	}

	/**
	 * Method to get the images
	 * Apr-1-2022 Added new images for popular wellness destinations to the resources folder and linked them in the code.
	 */
	private String getResizeIcon(int i) {
		String image = ""; 
		if (i==1){
			image = "<html><body><img width= '800' height='500' src='" + getClass().getResource("/resources/Dunton_Dolores_Colorado.jpg") + "'</body></html>";
		} else if (i==2){
			image = "<html><body><img width= '800' height='500' src='" + getClass().getResource("/resources/ClayoquatResort_VancouverBC.jpg") + "'</body></html>";
		} else if (i==3){
			image = "<html><body><img width= '800' height='500' src='" + getClass().getResource("/resources/LefayResort_GargnanoItaly.jpg") + "'</body></html>";
		} else if (i==4){
			image = "<html><body><img width= '800' height='500' src='" + getClass().getResource("/resources/RanchoLaPuerta_TecateMexico.jpg") + "'</body></html>";
		} else if (i==5){
			image = "<html><body><img width= '800' height='500' src='" + getClass().getResource("/resources/SanghaRetreat_SuzhouChina.jpg") + "'</body></html>";
		}
		return image;
	}
	
	/**
	 * Method to get the text values
	 * Apr-1-2022 Added similarly-formatted, readable descriptions, photo credits and information from the resorts' home page for each slide. 
	 * Green color scheme was used to portray the idea of 'nature' and 'wellness'instead of bright blue.
	 */
	private String getTextDescription(int i) {
		String text = ""; 
		if (i==1){
			text = "<html><body><font size='3', color='#fff'>#1 Dunton Resort - Dolores Colorado.</font> <font color='#79c976'> <br>Rustic luxury cabins and natural mineral hotsprings in an 1800's ghost town. <br> https://www.duntondestinations.com/hot-springs/ (Photo courtesy of Dunton Hot Springs.)</font></body></html>";
		} else if (i==2){
			text = "<html><body><font size='3', color='#fff'>#2 Clayoquat Resort - Vancouver, British Columbia </font> <font color='#79c976'><br>Off-grid lodging, local coastal menu, outdoor adventurers and relaxing spa. <br> https://clayoquotwildernesslodge.com/ (Photo courtesy of Clayoquat Wilderness Resort.)</font></body></html>";
		} else if (i==3){
			text = "<html><body><font size='3', color='#fff'>#3 Lefay Resort - Gargnano, Italy </font> <font color='#79c976'><br>Therapies, massage, natural beauty and luxury hotel accomodations. <br> https://www.lefayresorts.com/en (Photo courtesy of Lefay Resorts)</font></body></html>";
		} else if (i==4){
			text = "<html><body><font size='3', color='#fff'>#4 Rancho La Puerta - Tecate, Mexico </font> <font color='#79c976'> <br>Organic gourmet cuisine, spa, meditation labyrinth, and fitness activities. <br> https://rancholapuerta.com/ (Photo courtesy of Rancho La Puerta)</font></body></html>";
		} else if (i==5){
			text = "<html><body><font size='3', color='#fff'>#5 Sangha Retreat - Suzhou, China</font><font color='#79c976'> <br> Spa retreat with Chinese herbology-based treatments and fresh local cuisine. <br> https://www.sangharetreat.com/ (Photo courtesy of Sangha Retreat/OCTAVE Institute)</font></body></html>";
		}
		return text;
	}
	
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {

			@Override
			public void run() {
				SlideShow ss = new SlideShow();
				ss.setVisible(true);
			}
		});
	}
}